let hours_worked = 19
